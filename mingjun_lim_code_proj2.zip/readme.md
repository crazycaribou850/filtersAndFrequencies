Attached is the ipynb for this project.

In order to run, a 'sample_images' directory must exist containing all the input images from the 'input' directory.
Running the ipynb as is only defines the functions. In order to enable working with the images, set process = True in the second cell. This allows the notebook to run all blocks which do not only define functions.